<template>
  <div class="border-top bg-light p-3">
    <b-nav align="center">
      <b-nav-item href="/terms.html">{{ $t("general.terms") }}</b-nav-item>
      <b-nav-item href="/privacy.html">{{ $t("general.privacy") }}</b-nav-item>
    </b-nav>
  </div>
</template>
